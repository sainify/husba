import pathlib, subprocess, sys, zipfile, json
root=pathlib.Path.cwd()
def run(*args,**kw): return subprocess.run(args,check=True,**kw)
if not (root/"apps/web/index.html").exists(): sys.exit("Run this from /workspaces/husba")
if subprocess.run(["git","diff","--quiet"]).returncode or subprocess.run(["git","diff","--cached","--quiet"]).returncode:
 sys.exit("STOP: Commit or save existing changes first. Nothing was changed.")
with zipfile.ZipFile(root/"HUSBA-Complete-Redesign.zip") as z:
 patch=z.read("storefront.patch")
 paths=json.loads(z.read("changed-files.json"))
if subprocess.run(["git","apply","--reverse","--check","-"],input=patch,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode==0:
 print("This redesign is already applied.")
 sys.exit(0)
check=subprocess.run(["git","apply","--check","-"],input=patch)
if check.returncode: sys.exit("STOP: Source differs from this update. Send the error; do not force overwrite.")
run("git","apply","-",input=patch)
run("npm","run","build")
run("npm","run","check")
run("npm","test")
run("git","add","--",*paths)
run("git","commit","-m","Redesign complete HUSBA storefront with unified theme and motion")
print("Redesign tested and committed. Run git push origin main to publish through Pages.")
