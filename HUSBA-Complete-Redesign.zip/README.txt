HUSBA COMPLETE STOREFRONT REDESIGN — 22 September 2026

WHAT IS INCLUDED
Complete public-site design: home, collections, product details, films, story,
contact/enquiry forms, privacy, terms and 404. One ivory/rose design system,
editorial typography, responsive grids, matching mobile menu/footer, staggered
reveals, banner crossfades with pause/manual controls, native page transitions
where supported, reduced-motion support and lightweight hover/tap feedback.

The homepage now opens the complete product page rather than an incomplete
quick-view. Product details use a single video-first gallery and all real uploaded
images; no duplicated mobile downloads or fabricated extra photos. Home videos
load near the viewport; videos pause offscreen/on background. Real admin settings,
products, prices, categories, enquiry API and WhatsApp product links remain wired.
Empty/error states remain usable. The package contains no new mock catalogue.

INSTALL ON YOUR EXISTING REPOSITORY
1. Upload this ZIP, unchanged, to the GitHub repository ROOT and commit the upload.
   Do not delete old files. Uploading a ZIP alone does not install the redesign.
2. In Codespaces terminal:

cd /workspaces/husba && git switch main && git pull --ff-only
python3 - <<'CODE'
import zipfile
with zipfile.ZipFile("HUSBA-Complete-Redesign.zip") as z:
    exec(compile(z.read("apply-update.py"), "apply-update.py", "exec"))
CODE

3. If all checks pass and the commit is created:

git push origin main

Cloudflare Pages project `husba` should deploy the commit using its existing
Git integration. Wait for its successful production deployment, then open
https://husba.pages.dev/ and reload once. This package has not been deployed for you.
No extra npm dependencies are required.

SAFETY
The installer checks the patch before changing anything, stops on source conflicts,
and refuses existing tracked/staged edits. Do not force a failed patch.
Admin files, shared admin CSS, API client, Worker code/config, database and secrets
are not modified. scripts/build-web.mjs changes only the asset version.
Rollback after installation: git revert <redesign-commit-hash>, then git push.
Do not extract `changed-files` over unrelated code; use the guarded installer.

PACKAGE
storefront.patch: exact update against the current public source verified at
GitHub tree 1de7e94befcf47589b186b55ce44fe8732e87bf5.
changed-files/: complete updated files for review/manual comparison.
apply-update.py: guarded installation, build/check/test and local commit.
changed-files.json: exact list of changed paths.

VALIDATION
Passed npm run build, npm run check (11 JS files / 34 frontend files),
and all 8 existing backend/validation tests. Patch was applied to an independent
baseline copy and compared byte for byte to the final files.
Visual browser verification was blocked because the Chromium download timed out.
Existing tests do not prove live form submission, visual layout or video playback.
No live login/enquiry/database changes were made during validation.

PHONE CHECK AFTER DEPLOY
- Open homepage at normal zoom: hero, menu and footer share the same theme.
- Open/close menu, use links, and open/close enquiry sheet including Escape on desktop.
- Search/filter collection; open a piece; select its media thumbnails.
- Check product WhatsApp link contains the correct piece and page link.
- Play/pause a film; scroll away; confirm it pauses.
- Send one clearly marked test enquiry and confirm it appears in admin.
- Check 360/390/430px phone, tablet and desktop; no horizontal page overflow.
- Enable reduced motion: no automatic banner transitions or video playback.
- Confirm existing admin login and product editing still work.
