# HUSBA Atelier — final update package · 1 October 2026

This package updates **HUSBA Beads** (`sainify/husba`, `husba.pages.dev`). It is not the UZVERA package. HUSBA keeps WhatsApp, its current contact settings, product URLs, enquiries and authentication.

## Phone deployment — one copy-paste command

1. Download `HUSBA-Atelier-Final-Update.zip`. Upload the ZIP itself to the root of your existing **sainify/husba** GitHub repository and commit it. Do not extract it over your repository or delete existing files. Alternatively, upload it directly into `/workspaces/husba` in Codespaces.
2. Open the existing HUSBA Codespace terminal. Make sure your current work is committed, you are on `main`, Node 22+ is available and Wrangler is already connected to your existing Cloudflare account.
3. Paste this entire block once:

```bash
cd /workspaces/husba && git pull --ff-only && python3 - <<'PY'
from pathlib import Path
from zipfile import ZipFile
package = Path('HUSBA-Atelier-Final-Update.zip').resolve()
with ZipFile(package) as archive:
    installer = archive.read('install.py')
exec(compile(installer, 'install.py', 'exec'), {
    '__name__': '__main__',
    'PACKAGE_ZIP': str(package),
    'INSTALL_ARGS': ['--deploy'],
})
PY
```

Expected sequence: `Preflight passed` → backup path/branch → build and checks pass → 19 tests pass → update commit → `Deployed husba-beads-api` → Git push → Cloudflare **husba Pages** production build starts automatically.

The source ZIP is based on `husba-main (3).zip`. If any file being updated differs from that baseline, the installer deliberately stops **before overwriting it**. Send the latest source ZIP to merge your newer changes. Do not force it through. A conflicting/dirty repository is not an installation success.

4. In Cloudflare, wait for **husba → Deployments → Production** to show Success for the commit printed by the installer. The API Worker being deployed does not by itself mean the frontend has finished building.
5. Open https://husba.pages.dev/ and https://husba.pages.dev/admin/. For an already installed admin PWA, use the new **Update now** banner after saving edits. The first transition from the old PWA may need closing/reopening it or its existing refresh control. Do not clear credentials or storage.

Existing Pages Git settings remain: root `/`, build `npm run build`, output `dist`, production branch `main`. The root `functions/` directory is now used for request-time product sharing metadata and the sitemap. Pages must deploy Functions, not a static-only drag-and-drop upload of `dist`. The API still uses `worker/wrangler.toml`. Both existing Wrangler files are unchanged and never overwritten by the installer.

For inspection without changes, replace `['--deploy']` with `['--dry-run']` in the same block. `['--apply']` applies and tests locally without committing, pushing or deploying. A subsequent `--deploy` requires those local changes to be reviewed and committed first.

## Included

- `source/`: full clean project with exact paths, including existing assets and untouched configurations; no old ZIP archives, build output, credentials or dependencies.
- `install.py` and `update-manifest.json`: SHA-256 conflict detection, package integrity checks, backup branch/files, validation and explicit Worker deployment.
- `source/docs/ATELIER-UPDATE.md`: inspection, design system, page plan, feature decisions, backend limitations and deployment/rollback notes.
- `source/docs/ATELIER-TESTING.md`: tested vs. untested details.

The installer does not run D1 migrations, seed data, reset credentials, write secrets, change contact settings, or overwrite Wrangler account/binding configuration. It stages only the listed update files. It restores changed source files if local validation fails. A deployment or Git push failure leaves a reviewed commit and backup so you can inspect/retry; it does not claim a multi-service atomic rollback.
