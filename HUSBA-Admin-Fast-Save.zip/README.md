# HUSBA Admin Fast Save

This is a targeted update for the Next.js HUSBA admin installed from `HUSBA-Next-Final.zip`. It contains complete replacement files at their exact paths. It preserves Worker, D1, Cloudinary, login credentials, products and account settings.

- A confirmed save updates the visible item immediately; it no longer waits for the full workspace catalogue to reload.
- The dashboard summary refreshes in the background.
- A stalled admin request stops after 20 seconds and reports that the save outcome is uncertain. Inspect the item before retrying.
- A source hash guard refuses to apply to a different version. The installer creates a backup branch and private copy before editing, then runs tests and production build before pushing.

## Phone deployment

Upload `HUSBA-Admin-Fast-Save.zip` to the root of the `sainify/husba` GitHub repository on `main` and commit the upload. In the existing Codespace terminal run **one command**:

```bash
cd /workspaces/husba && git pull --ff-only && python3 -c 'import zipfile; exec(compile(zipfile.ZipFile("HUSBA-Admin-Fast-Save.zip").read("install.py"), "install.py", "exec"), {"__name__":"__main__"})' --apply
```

Expected final line: `Pushed to main. Wait for the Cloudflare Pages production build to succeed, then reopen /admin/.`

If the checkout has other changes, the installer stops before editing. Keep those changes safe and review them first. If the hash check fails, this patch does not match the deployed code; do not force it.

Rollback: use the printed backup branch to restore the previous source in a new commit; the update does not migrate D1. Example: `git restore --source backup/husba-before-fast-save-TIMESTAMP -- components/Admin.jsx lib/admin-api.js` and remove the added test, then rebuild, commit and push. Replace `TIMESTAMP` with the printed branch name. The uploaded ZIP can remain in the repository.

Check after deployment: edit a product description in `/admin/`, save, confirm the drawer closes after Worker confirmation, refresh and check the persisted value. Check a phone with slow/offline network for the timeout message. The actual live Worker/network latency was not measured in this package.
