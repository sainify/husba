"""Apply the HUSBA admin speed patch to an existing Next.js checkout."""
import hashlib
import shutil
import subprocess
import sys
import tempfile
import zipfile
from datetime import datetime, timezone
from pathlib import Path

PACKAGE = Path.cwd() / 'HUSBA-Admin-Fast-Save.zip'
FILES = {
    'components/Admin.jsx': 'a9d0873d1d71f3382f93a876342da579aaead1eb915cac34ed3e9275fad85f00',
    'lib/admin-api.js': '1a9743fad1c9985ece51f0f2df46713cdeb766dcd8bb27d26c9a2855226dc494',
}
NEW_FILE = 'tests/admin-request-timeout.test.mjs'


def run(*args):
    return subprocess.run(args, check=True, text=True, capture_output=True).stdout.strip()


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    if sys.argv[1:] not in (['--apply'], ['--dry-run']):
        raise SystemExit('Use --dry-run or --apply.')
    if not PACKAGE.is_file():
        raise SystemExit(f'Upload {PACKAGE.name} to the repository root first, then git pull.')
    root = Path.cwd()
    if run('git', 'rev-parse', '--show-toplevel') != str(root):
        raise SystemExit('Run from the HUSBA repository root.')
    if run('git', 'branch', '--show-current') != 'main':
        raise SystemExit('Switch to main before applying this patch.')
    status = run('git', 'status', '--porcelain')
    if status:
        raise SystemExit('Working tree contains changes. Commit or safely back them up first. No files changed.\n' + status)
    if run('git', 'rev-parse', 'HEAD') != run('git', 'rev-parse', 'origin/main'):
        raise SystemExit('main and origin/main differ. Run git pull --ff-only first.')
    with zipfile.ZipFile(PACKAGE) as archive:
        staged = {}
        for filename, expected in FILES.items():
            current = root / filename
            if not current.is_file() or sha(current.read_bytes()) != expected:
                raise SystemExit(f'{filename} differs from the verified Next.js release. No files changed; do not force apply.')
            staged[filename] = archive.read(filename)
        if (root / NEW_FILE).exists():
            raise SystemExit(f'{NEW_FILE} already exists. No files changed.')
        staged[NEW_FILE] = archive.read(NEW_FILE)
    print('Verified existing files and patch archive.')
    if sys.argv[1] == '--dry-run':
        print('Dry run passed. No files changed.')
        return
    stamp = datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S')
    backup_branch = f'backup/husba-before-fast-save-{stamp}'
    backup_dir = Path(tempfile.mkdtemp(prefix='husba-fast-save-backup-'))
    old_commit = run('git', 'rev-parse', 'HEAD')
    run('git', 'branch', backup_branch)
    for filename in FILES:
        dest = backup_dir / filename
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(root / filename, dest)
    try:
        for filename, data in staged.items():
            dest = root / filename
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(data)
        subprocess.run(['npm', 'test'], check=True)
        subprocess.run(['npm', 'run', 'build'], check=True)
        subprocess.run(['npm', 'run', 'check'], check=True)
    except Exception:
        for filename in FILES:
            shutil.copy2(backup_dir / filename, root / filename)
        (root / NEW_FILE).unlink(missing_ok=True)
        print(f'Build failed; source restored. Backup at {backup_dir}.', file=sys.stderr)
        raise
    subprocess.run(['git', 'add', *staged], check=True)
    subprocess.run(['git', 'commit', '-m', 'Speed up admin saves and bound stalled requests'], check=True)
    print(f'Validated and committed. Prior commit: {old_commit}. Backup branch: {backup_branch}.')
    print(f'Private source backup: {backup_dir}.')
    subprocess.run(['git', 'push', 'origin', 'main'], check=True)
    print('Pushed to main. Wait for the Cloudflare Pages production build to succeed, then reopen /admin/.')


if __name__ == '__main__':
    main()
