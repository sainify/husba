# HUSBA Admin — Premium redesign

A full visual redesign of the HUSBA Beads admin panel. Only the admin
frontend changed. The Worker, D1 schema, API routes, authentication and
`api.js` are untouched.

## What was inspected before changing anything

`apps/web/admin/index.html`, `assets/css/admin.css`, `assets/js/admin.js`,
`assets/js/api.js`, `config.template.js`, and `worker/src/index.js` were all
read in full to confirm the real auth flow and every endpoint shape before
any redesign work started:

- Login is a real email/password form (`POST /api/admin/login`) that returns
  an HMAC-signed session token. The token is kept in `localStorage` with an
  IndexedDB backup, sent as `Authorization: Bearer …`, and mirrored by the
  Worker into an `HttpOnly` cookie. `admin.js` also refreshes it every 10
  minutes via `GET /api/admin/session`.
- Every resource call (`products`, `categories`, `videos`, `enquiries`,
  `settings`, `dashboard`) and their exact field names were cross-checked
  against `worker/src/index.js` — nothing here was guessed.

## Files changed

| File | What changed |
|---|---|
| `apps/web/admin/index.html` | Full markup redesign. Every `data-*` hook the JS relies on was preserved 1:1 (verified programmatically — see Testing below). Added the one element `admin.js` was already wired for but the old HTML was missing (`data-clear-cache`, in the sidebar as **"Refresh app files"**) and a decorative left panel for the split-screen login. |
| `apps/web/assets/css/admin.css` | Complete rewrite: ivory/burgundy editorial design system, Cormorant Garamond + Inter typography, native-feeling bottom nav on mobile, sidebar on desktop, redesigned cards/tables/dialogs/login/toasts/skeletons, dark-mode variant, `prefers-reduced-motion` support. |
| `apps/web/assets/js/admin.js` | Two small **additive** enhancements only — no API calls, auth logic, state handling, routing or CRUD logic changed: <br>1. The enquiry edit dialog now shows a read-only summary (customer, phone, requirement, quantity, message) above the existing status/notes fields. <br>2. Product image URL fields now show a live preview thumbnail as you type/paste a Cloudinary URL. <br>The `[data-clear-cache]` listener (already present in the old file, just missing its button) now has something to attach to. |
| `apps/web/admin/manifest.webmanifest` | Fixed leftover branding from a previous rebrand (`UZVÉRA Admin` → `HUSBA Admin`) and aligned `theme_color`/`background_color` with the new palette. Icons, `start_url`, `scope`, shortcuts unchanged. |
| `apps/web/admin/sw.js` | Bumped cache name `husba-admin-v11` → `husba-admin-v12` only, so the new CSS/JS aren't served stale from the old cache. Cached file list unchanged (no paths moved). |

**Not touched at all:** `worker/`, `assets/js/api.js`, `config.template.js`,
D1 migrations, every non-admin page, `admin/icons/*`.

## Why the design doesn't add "new" features

The brief asked me not to invent backend functionality. Two things worth
knowing:

- The Worker also has a working `reviews` CRUD endpoint (`/api/admin/reviews`)
  that the old admin UI never surfaced. I left it out of this redesign
  rather than build a whole new section you didn't ask for — happy to add
  a **Reviews** view in a follow-up if you want it.
- "Drag & drop" media in the brief would imply real file upload, but the
  backend only accepts pasted Cloudinary URLs (no upload endpoint exists).
  So instead of a fake uploader, product/video image fields now show a
  live preview of the pasted URL — genuinely useful, nothing invented.
- There's no "duplicate product" endpoint, so that action wasn't added.

## Testing performed

Since this environment has no access to your live Cloudflare Worker or a
browser, I ran everything that could be verified without one, using your
own repo's own tooling — all offline, no network calls:

- `npm run build` — succeeds, `dist/admin/index.html` etc. all generate correctly.
- `npm run check` — passes (11 JS files, 33 frontend files): no syntax
  errors, **no exposed secrets**, no unresolved `__TOKEN__` build
  placeholders in the shipped `dist/`.
- `npm test` — all 8 existing Worker tests still pass unmodified (auth,
  validation, CORS, sanitization) — expected, since `worker/src/index.js`
  was not touched.
- `node --check` on the edited `admin.js` — no syntax errors.
- Programmatic diff of every `data-*` attribute `admin.js` queries against
  the new HTML — **zero missing hooks** (the only "missing" ones are the
  handful admin.js itself writes into table rows at runtime, e.g.
  `data-edit`, `data-delete`, `data-toggle-product` — that's expected).
- Byte-for-byte diff confirming `api.js`, `config.template.js` and
  `worker/src/index.js` are unchanged.

**What I could not test:** an actual browser session against your live
Worker (login round-trip, real CRUD, real console output, real Lighthouse/
visual QA at each breakpoint). The CSS was written directly against your
real markup and existing class names/selectors (table row structure,
`data-label` responsive-table pattern, dialog structure, etc.), and the
mobile/desktop breakpoints follow the same structure the old CSS used, but
please do a quick pass on a phone and desktop after deploying before you
fully trust it, the way you would for any frontend change.

## How to test locally

From the repo root, with these files copied in:

```
npm run build
npm run check
npm test
npm run preview
```

Open `http://localhost:4173/admin/`. In local preview `DEMO_MODE` behavior
matches whatever your build variables already produce — this is unchanged
by this redesign.

## How to deploy

1. Copy the 5 files below into your repo, preserving their paths exactly:
   - `apps/web/admin/index.html`
   - `apps/web/admin/manifest.webmanifest`
   - `apps/web/admin/sw.js`
   - `apps/web/assets/css/admin.css`
   - `apps/web/assets/js/admin.js`
2. Commit and push to `main` (or open a PR) — Cloudflare Pages' Git
   integration builds and deploys as usual. Nothing about the Worker,
   D1, or Pages build settings needs to change.
3. Because the service worker cache name was bumped, visitors (including
   you) will automatically get the new admin assets on next load — no
   manual cache-busting needed. If you still see the old design after
   deploying, use the new **"Refresh app files"** button in the sidebar,
   or hard-refresh once.

## Cache/version changes made

- `apps/web/admin/sw.js`: `CACHE = "husba-admin-v11"` → `"husba-admin-v12"`.
  This is the only change in that file. The cached shell file list is
  identical (no file paths were renamed or moved).
