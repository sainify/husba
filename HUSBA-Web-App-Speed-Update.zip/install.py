#!/usr/bin/env python3
"""Apply the verified HUSBA update. Defaults to a read-only dry run."""
import argparse, datetime, hashlib, json, os, re, shutil, subprocess, sys, zipfile
from pathlib import Path, PurePosixPath

def digest(data): return hashlib.sha256(data).hexdigest()
def run(args, cwd, capture=False):
    result=subprocess.run(args,cwd=cwd,check=True,text=True,stdout=subprocess.PIPE if capture else None)
    return result.stdout.strip() if capture else ''
def abort(message): raise SystemExit('STOP: '+message)
def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--zip',default=globals().get('PACKAGE_ZIP','HUSBA-Web-App-Speed-Update.zip'))
    parser.add_argument('--repo',default='.')
    group=parser.add_mutually_exclusive_group();group.add_argument('--dry-run',action='store_true');group.add_argument('--apply',action='store_true');group.add_argument('--deploy',action='store_true')
    args=parser.parse_args(globals().get('INSTALL_ARGS'))
    repo=Path(args.repo).resolve();archive=Path(args.zip).resolve();write=args.apply or args.deploy
    if not (repo/'worker/wrangler.toml').is_file(): abort('Run this in the existing HUSBA repository.')
    if Path(run(['git','rev-parse','--show-toplevel'],repo,True)).resolve()!=repo: abort('Run from the repository root.')
    remote=run(['git','remote','get-url','origin'],repo,True)
    if not re.search(r'github\.com[:/]sainify/husba(?:\.git)?$',remote): abort('This package is only for github.com/sainify/husba. Do not apply it to UZVERA.')
    branch=run(['git','branch','--show-current'],repo,True)
    if branch!='main': abort('Switch to the intended main branch before installing; no branch was changed.')
    if run(['git','status','--porcelain','--untracked-files=no'],repo,True): abort('Tracked files have uncommitted changes. Commit or back them up first; nothing was overwritten.')
    config=(repo/'worker/wrangler.toml').read_text()
    if not re.search(r'name\s*=\s*"husba-beads-api"',config) or not re.search(r'binding\s*=\s*"DB"',config): abort('Worker identity/binding differs. Review it before deploying.')
    with zipfile.ZipFile(archive) as z:
        manifest=json.loads(z.read('update-manifest.json'));pending=[];conflicts=[]
        for entry in manifest['changes']:
            name=entry['path'];parts=PurePosixPath(name).parts
            if not parts or name.startswith('/') or '..' in parts: abort('Unsafe archive path.')
            if any(part in {'.git','.env','.dev.vars','.wrangler','node_modules'} for part in parts) or Path(name).name.startswith('.env') or Path(name).name.startswith('wrangler.'): abort('Protected configuration in update manifest.')
            dest=repo/name
            if any(p.is_symlink() for p in [dest,*dest.parents] if p!=repo.parent): abort('Symlink destination requires manual review: '+name)
            data=z.read('source/'+name)
            if digest(data)!=entry['after']: abort('Package integrity mismatch: '+name)
            current=digest(dest.read_bytes()) if dest.is_file() else None
            if current==entry['after']: continue
            if current!=entry['before']: conflicts.append(name)
            else: pending.append((name,data))
        if conflicts: abort('Source differs from the supplied baseline. No files changed. Send the latest source ZIP for a merged update:\n'+'\n'.join(conflicts))
        print(f'Preflight passed. {len(pending)} files to update. Wrangler configs, credentials, media and D1 records are preserved.',flush=True)
        if not write:
            print('DRY RUN: no files, Git history, Cloudflare resources or database were changed.');return
        node=run(['node','-p','process.versions.node'],repo,True)
        if int(node.split('.')[0])<22: abort('Use Node.js 22 or newer for the full validation suite.')
        stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%d-%H%M%S-%f')
        backup=repo.parent/'husba-private-backups'/('speed-'+stamp);backup.mkdir(parents=True)
        original_head=run(['git','rev-parse','HEAD'],repo,True);backup_branch='backup/husba-speed-'+stamp
        run(['git','branch',backup_branch,original_head],repo)
        metadata={'original_head':original_head,'backup_branch':backup_branch,'files':[]}
        for name,data in pending:
            dest=repo/name;existed=dest.exists();metadata['files'].append({'path':name,'existed':existed})
            if existed:
                saved=backup/'files'/name;saved.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(dest,saved)
        (backup/'rollback.json').write_text(json.dumps(metadata,indent=2))
        print('Backup: '+str(backup)+'\nBackup branch: '+backup_branch,flush=True)
        try:
            for name,data in pending:
                dest=repo/name;dest.parent.mkdir(parents=True,exist_ok=True);temp=dest.with_name(dest.name+'.speed-tmp');temp.write_bytes(data);temp.replace(dest)
            for task in ['build','check','test']: run(['npm','run',task],repo)
        except Exception:
            for entry in metadata['files']:
                dest=repo/entry['path']
                if entry['existed']: shutil.copy2(backup/'files'/entry['path'],dest)
                elif dest.exists(): dest.unlink()
            print('Validation failed. Updated source files were restored. Backup retained at '+str(backup),file=sys.stderr)
            raise
        if not args.deploy:
            print('Applied and validated locally. Nothing deployed or pushed. Review git diff.');return
        names=[entry['path'] for entry in manifest['changes']]
        run(['git','add','--',*names],repo)
        staged=subprocess.run(['git','diff','--cached','--quiet'],cwd=repo).returncode
        if staged==1: run(['git','commit','-m','Reduce HUSBA admin startup and save latency'],repo)
        elif staged!=0: abort('Could not inspect staged update.')
        update_commit=run(['git','rev-parse','HEAD'],repo,True)
        print('Verified commit: '+update_commit,flush=True)
        # Explicit API target. No d1 execute/migrations, secret put or account writes.
        run(['npx','--yes','wrangler@4','deploy','--config','worker/wrangler.toml','--keep-vars'],repo)
        run(['git','push','origin','main'],repo)
        print('\nAPI deployed; source pushed. Cloudflare Pages Git integration will now build the frontend.\nWait for the husba Pages production deployment to show Success for commit '+update_commit[:8]+'.\nThen verify https://husba.pages.dev/ and https://husba.pages.dev/admin/.\nRollback information: '+str(backup/'rollback.json'),flush=True)

if __name__=='__main__':
    try: main()
    except subprocess.CalledProcessError as error:
        print('Command failed with exit code '+str(error.returncode)+'. Its original output is above. No later deploy steps ran. Fix that issue and rerun the same installer; existing updated files are recognized.',file=sys.stderr)
        sys.exit(error.returncode or 1)
