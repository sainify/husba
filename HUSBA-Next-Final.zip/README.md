# HUSBA Beads · Next.js update

Full source, built static site, and safe installer for the existing `sainify/husba` repository. Public pages and the primary `/admin/` workspace run on Next.js 16.3.8 with React. The previous admin remains available at `/admin/classic/` as a compatibility fallback. The existing Cloudflare Worker, D1 data, Pages Functions, secrets and Cloudinary assets are retained.

## One command from a phone Codespace

Upload `HUSBA-Next-Final.zip` into `/workspaces/husba`, then run this **one line** from the Codespace terminal:

```bash
cd /workspaces/husba && python3 -c 'import zipfile,tempfile,subprocess,pathlib; d=pathlib.Path(tempfile.mkdtemp(prefix="husba-next-")); zipfile.ZipFile("HUSBA-Next-Final.zip").extractall(d); subprocess.run(["python3",str(d/"install.py"),"--repo","/workspaces/husba","--deploy"],check=True)'
```

The installer requires a clean `main` checkout of `sainify/husba` matching the inspected October 2 baseline. It first builds and tests the extracted package, checks the Git remote and latest main, creates a backup branch and private file backup, installs and tests again, then commits and pushes. It refuses conflicting changes. It does not run D1 migrations or reset credentials. Cloudflare Pages should keep its existing `npm run build` and `dist` output configuration; the build produces `dist/` automatically. Wait for a successful Pages deployment before evaluating the live site. The Worker source is unchanged.

For a no-change check, extract into a separate folder and run `python3 install.py --repo /workspaces/husba --dry-run`.

## Actual verification

- Next.js optimized static export compiled all public routes and `/admin/`.
- Nine test files passed, including catalogue pagination, admin token renewal and existing Worker regression tests.
- `npm audit --omit=dev --audit-level=high` reported no known vulnerabilities for pinned production dependencies at packaging time.
- Output check found required routes, admin classic fallback, service worker and CSP hashes.
- Cloudflare deployment and real admin sign-in/save were **not** exercised in this workspace; verify on the live site after Pages shows Success.
- Automated browser screenshots were unavailable because the browser binary download failed. Use the phone checklist in `docs/next-migration.md`.

No new D1 table or binding is required. Next static export uses the existing Worker API. Admin statuses remain `new`, `contacted`, and `closed`, matching the existing API; no unsupported status names were introduced.
