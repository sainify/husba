#!/usr/bin/env python3
"""Safe, one-command HUSBA Next migration from a verified extracted ZIP."""
import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tarfile
from datetime import datetime, timezone
from pathlib import Path

SOURCE = Path(__file__).resolve().parent
ROOT_FILES = ["package.json", "package-lock.json", ".gitignore", ".node-version", "next.config.mjs"]
ROOT_DIRS = ["app", "components", "lib", "public"]
EXTRA = ["scripts/prepare.mjs", "scripts/assemble.mjs", "scripts/check.mjs",
         "tests/next-catalogue.test.mjs", "tests/next-admin-session.test.mjs",
         "docs/next-migration.md"]
PATHS = ROOT_FILES + ROOT_DIRS + EXTRA


def run(*command, cwd=None):
    print("+", " ".join(map(str, command)), flush=True)
    return subprocess.run(command, cwd=cwd, check=True)


def output(*command, cwd=None):
    return subprocess.check_output(command, cwd=cwd, text=True).strip()


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--deploy", action="store_true", help="Commit and push main after passing checks")
    args = parser.parse_args()
    repo = args.repo.resolve()
    if repo == SOURCE or SOURCE.is_relative_to(repo):
        raise SystemExit("Extract the update OUTSIDE the repository (the one-line command does this).")
    if not (repo / ".git").exists():
        raise SystemExit("Target is not a Git checkout.")
    if output("git", "branch", "--show-current", cwd=repo) != "main":
        raise SystemExit("Switch to the main branch first. No files were changed.")
    remote = output("git", "remote", "get-url", "origin", cwd=repo)
    if "sainify/husba" not in remote:
        raise SystemExit("Unexpected GitHub repository. No files were changed.")
    if output("git", "diff", "--name-only", cwd=repo) or output("git", "diff", "--cached", "--name-only", cwd=repo):
        raise SystemExit("Tracked local changes found. Commit or back them up before installing.")
    baseline = json.loads((SOURCE / "baseline-hashes.json").read_text())
    for rel, expected in baseline.items():
        target = repo / rel
        if not target.is_file() or sha(target) != expected:
            raise SystemExit(f"{rel} differs from the inspected baseline. No files were changed.")
    for rel in PATHS:
        src, target = SOURCE / rel, repo / rel
        if not src.exists():
            raise SystemExit(f"Package incomplete: {rel}")
        if rel not in baseline and target.exists():
            raise SystemExit(f"Conflicting path already exists: {rel}. No files were changed.")
    print(f"Validated source, repository and {len(PATHS)} paths.")
    if args.dry_run:
        print("DRY RUN ONLY. Nothing changed.")
        return
    # Verify dependencies and the complete static build before touching the checkout.
    run("npm", "ci", "--no-audit", "--no-fund", cwd=SOURCE)
    run("npm", "run", "build", cwd=SOURCE)
    run("npm", "test", cwd=SOURCE)
    run("npm", "run", "check", cwd=SOURCE)
    run("git", "fetch", "origin", "main", cwd=repo)
    if output("git", "rev-parse", "HEAD", cwd=repo) != output("git", "rev-parse", "origin/main", cwd=repo):
        raise SystemExit("Your main branch is not at the latest origin/main. No files were changed.")
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
    backup = repo.parent / "husba-private-backups" / f"next-{stamp}"
    backup.mkdir(parents=True, exist_ok=False)
    previous = output("git", "rev-parse", "HEAD", cwd=repo)
    (backup / "previous-commit.txt").write_text(previous + "\n")
    with tarfile.open(backup / "overwritten-files.tar.gz", "w:gz") as archive:
        for rel in PATHS:
            if (repo / rel).exists():
                archive.add(repo / rel, arcname=rel)
    branch = f"backup/husba-before-next-{stamp}"
    run("git", "branch", branch, cwd=repo)
    installed = []
    try:
        for rel in PATHS:
            src, target = SOURCE / rel, repo / rel
            target.parent.mkdir(parents=True, exist_ok=True)
            if src.is_dir():
                shutil.copytree(src, target)
            else:
                shutil.copy2(src, target)
            installed.append(rel)
        run("npm", "ci", "--no-audit", "--no-fund", cwd=repo)
        run("npm", "run", "build", cwd=repo)
        run("npm", "test", cwd=repo)
        run("npm", "run", "check", cwd=repo)
    except Exception:
        for rel in reversed(installed):
            target = repo / rel
            if target.is_dir(): shutil.rmtree(target)
            elif target.exists(): target.unlink()
        with tarfile.open(backup / "overwritten-files.tar.gz", "r:gz") as archive:
            archive.extractall(repo, filter="data")
        print(f"Build failed; files restored. Backup: {backup}", file=sys.stderr)
        raise
    if args.deploy:
        run("git", "add", "--", *PATHS, cwd=repo)
        run("git", "commit", "-m", "Migrate HUSBA public site and admin to Next.js", cwd=repo)
        run("git", "push", "origin", "main", cwd=repo)
        print("Source pushed. Wait for Cloudflare Pages production build to show Success.")
    print(f"Update installed. Previous commit {previous}. Backup: {backup}. Branch: {branch}")


if __name__ == "__main__":
    main()
