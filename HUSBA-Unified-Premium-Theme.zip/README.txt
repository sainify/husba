Unified admin theme: dashboard, drawer, header, bottom navigation, typography, PWA theme colour. Reduced-motion support. Frontend only; no authentication or Worker changes.
Apply patch from repository root; npm run build; npm run check; commit changed frontend files and push.
Validation: build, source checks, whitespace checks passed. Phone visual verification pending.
