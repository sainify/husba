Deploy routing correction
Root wrangler.toml explicitly selects worker/src/index.js and existing D1 binding. npm run deploy explicitly selects worker/wrangler.toml. Secrets are not embedded or reset.
Cloudflare Worker Builds: repository root /, deploy command npm run deploy. Do not deploy dist as the API Worker. Cloudflare Pages keeps npm run build and dist output.
Validation: 8 tests pass, frontend checks pass, root Worker entry and existing database binding verified. Live deployment still required.
