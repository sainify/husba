HUSBA mobile alignment fix

Based on sainify/husba main at 053219095526a6ee3a5a26c124146bdddc0db8e4.

Changes:
- Mobile header uses two rows with wrapping action buttons.
- App title and monogram have dedicated layout styles.
- Forms/fieldsets shrink correctly to mobile width with smaller nested padding.
- Hidden controls, including Install app, stay hidden.
- Bottom navigation labels can shrink; toast messages sit above navigation.
- Asset version and service-worker cache version updated.

Apply using GitHub:
Replace these three files in the existing repository using the matching paths in this ZIP:
  apps/web/assets/css/admin.css
  apps/web/admin/sw.js
  scripts/build-web.mjs
Commit the changes. If Cloudflare Pages is connected to that branch with automatic deployments enabled, it will build the update.
Keep existing Cloudflare build settings and environment variables.

Alternatively, in your repository terminal, place mobile-alignment.patch in the repository root and run:
  git apply --check mobile-alignment.patch
  git apply mobile-alignment.patch
  npm run build
  npm run check
  git add apps/web/assets/css/admin.css apps/web/admin/sw.js scripts/build-web.mjs
  git commit -m "Fix admin mobile layout and hidden PWA controls"
  git push
If git apply --check reports a conflict, stop rather than overwriting newer work.

After successful deployment, reopen the PWA online and use Refresh app files in its sidebar if old styling remains.

Validation completed: npm run build, npm run check, git diff --check.
Visual browser testing was unavailable; check dashboard and Website content at 320, 360, 390, 430 and desktop widths after deployment.
No live deployment was performed. Connected GitHub access is read-only.
