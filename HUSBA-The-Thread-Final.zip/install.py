"""Install the complete HUSBA The Thread release safely into an existing Next checkout."""
import hashlib
import json
import re
import shutil
import subprocess
import sys
import tempfile
import zipfile
from datetime import datetime, timezone
from pathlib import Path

ARCHIVE = Path.cwd() / 'HUSBA-The-Thread-Final.zip'


def run(*args):
    return subprocess.run(args, check=True, text=True, capture_output=True).stdout.strip()


def digest(data):
    return hashlib.sha256(data).hexdigest()


def main():
    if sys.argv[1:] not in (['--apply'], ['--dry-run']):
        raise SystemExit('Use --dry-run or --apply.')
    root = Path.cwd()
    if not ARCHIVE.is_file():
        raise SystemExit('Upload HUSBA-The-Thread-Final.zip to the repository root and pull main first.')
    if run('git', 'rev-parse', '--show-toplevel') != str(root):
        raise SystemExit('Run from the HUSBA Git repository root.')
    if run('git', 'branch', '--show-current') != 'main':
        raise SystemExit('Switch to main first.')
    remote = run('git', 'remote', 'get-url', 'origin')
    if not re.search(r'(?:[:/])sainify/husba(?:\.git)?$', remote):
        raise SystemExit('Unexpected Git remote. No source changed.')
    status = run('git', 'status', '--porcelain')
    if status:
        raise SystemExit('Uncommitted files found; preserve them before updating. No source changed.\n' + status)
    prior = run('git', 'rev-parse', 'HEAD')
    if prior != run('git', 'rev-parse', 'origin/main'):
        raise SystemExit('Local main differs from origin/main. Pull with --ff-only first.')
    with zipfile.ZipFile(ARCHIVE) as package:
        changes = json.loads(package.read('manifest.json'))
        staged = {}
        for name, hashes in changes.items():
            if name.startswith('/') or '..' in Path(name).parts or name.startswith(('.env', '.wrangler/')) or name in ('wrangler.toml', 'worker/wrangler.toml'):
                raise SystemExit('Unsafe package path; no files changed.')
            target = root / name
            before = target.read_bytes() if target.is_file() else None
            actual = digest(before) if before is not None else None
            if actual != hashes['base']:
                raise SystemExit(f'Conflict in {name}. Expected {hashes["base"]}, got {actual}. No files changed.')
            after = package.read('source/' + name)
            if digest(after) != hashes['new']:
                raise SystemExit(f'Corrupt package content: {name}. No files changed.')
            staged[name] = after
    print(f'Verified {len(staged)} source changes against installed release.')
    if sys.argv[1] == '--dry-run':
        print('Dry run passed. No source changed.')
        return
    stamp = datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S')
    branch = f'backup/husba-before-thread-{stamp}'
    backup = Path(tempfile.mkdtemp(prefix='husba-thread-backup-', dir=root.parent))
    run('git', 'branch', branch)
    for name in staged:
        target = root / name
        if target.exists():
            destination = backup / name
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(target, destination)
    try:
        for name, data in staged.items():
            target = root / name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(data)
        # Existing lockfile and dependencies are unchanged. Install if Codespace is fresh.
        if not (root / 'node_modules/next').exists():
            subprocess.run(['npm', 'ci'], check=True)
        for command in (['npm', 'test'], ['npm', 'run', 'build'], ['npm', 'run', 'check']):
            subprocess.run(command, check=True)
    except Exception:
        for name in staged:
            saved = backup / name
            if saved.exists():
                target = root / name
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(saved, target)
            else:
                (root / name).unlink(missing_ok=True)
        print(f'Validation failed. Source restored; backup: {backup}', file=sys.stderr)
        raise
    subprocess.run(['git', 'add', '--', *staged], check=True)
    subprocess.run(['git', 'commit', '-m', 'Apply HUSBA The Thread design'], check=True)
    new_commit = run('git', 'rev-parse', 'HEAD')
    print(f'Previous commit: {prior}. Backup branch: {branch}. Private backup: {backup}.')
    print(f'New commit: {new_commit}. Rollback: git revert {new_commit} && git push origin main')
    subprocess.run(['git', 'push', 'origin', 'main'], check=True)
    print('Pushed to main. Wait for the Cloudflare Pages production build to show Success.')
    print('Worker and D1 were not changed.')


if __name__ == '__main__':
    main()
