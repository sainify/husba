import pathlib, subprocess, sys, zipfile, json
root=pathlib.Path.cwd()
def run(*args,**kw): return subprocess.run(args,check=True,**kw)
if not (root/"apps/web/index.html").exists(): sys.exit("Run this from /workspaces/husba")
if subprocess.run(["git","diff","--quiet"]).returncode or subprocess.run(["git","diff","--cached","--quiet"]).returncode:
 sys.exit("STOP: Existing edits detected. Commit or save them first; no files changed.")
with zipfile.ZipFile(root/"HUSBA-Claude-Final.zip") as z:
 patch=z.read("claude-design.patch")
 paths=json.loads(z.read("changed-files.json"))
if subprocess.run(["git","apply","--reverse","--check","-"],input=patch,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode==0:
 print("Claude design update is already applied.")
 sys.exit(0)
if subprocess.run(["git","apply","--check","-"],input=patch).returncode:
 sys.exit("STOP: Source mismatch. Send this error; do not force overwrite.")
run("git","apply","-",input=patch)
run("npm","run","build")
run("npm","run","check")
run("npm","test")
run("git","add","--",*paths)
run("git","commit","-m","Integrate Claude storefront design with verified HUSBA API contracts")
print("Ready. Run git push origin main for the connected Pages deployment.")
