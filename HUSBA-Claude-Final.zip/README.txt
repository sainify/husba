HUSBA — CLAUDE DESIGN, INTEGRATED FINAL UPDATE
22 September 2026

This is the supplied Claude design integrated into your current HUSBA project.
It replaces the previous public redesign, preserving Claude's ivory/rosewood
palette, Fraunces/Manrope type, image hero, circular categories, compact product
cards, reels, story section, menu, footer, filters and enquiry page.

WHAT WAS CORRECTED
- Uses window.HUSBA_CONFIG.API_BASE from your existing Cloudflare build.
- Uses actual Worker responses: bootstrap.products and product response.product.
- Keeps show_price, price_label, statuses and video/image media types correct.
- Maps category slugs, code/name search and available-only filtering correctly.
- Fetches additional collection pages where needed; deduplicates bootstrap calls.
- Does not silently substitute Claude's dummy products on API failure.
- Sends phone, product_id, product_name, enquiry_type and other real enquiry fields.
- Keeps optional configured Turnstile protection and prevents duplicate form submits.
- Uses admin-managed WhatsApp number, logo, announcements and footer description.
- Wires existing banner images, hero content, section visibility and titles.
- Keeps original policy text and existing /about/, /privacy/ and /terms/ routes;
  the supplied /story/ and /policies/* routes also work.
- Escapes product/category/price text before creating HTML.
- Adds pause/manual hero controls and accessible film play/pause controls.
- Pauses offscreen/background videos; respects reduced motion and data-saving.
- Fixes mobile menu focus/scroll state, native hidden behavior, button CSS and
  removes the route-intercepting veil that could strand browser-back navigation.
- Preserves the Mohd Husain copyright link.

Admin, Worker, database, secrets, API client used by admin and deployment config
are not changed. _headers adds only Google Fonts style/font hosts required by the
supplied design. scripts/build-web.mjs changes only the static asset version.
No npm dependencies are added. Real products/photos must come from your admin;
the package does not invent catalogue items or duplicate images to fill a count.

INSTALL — ANDROID / CODESPACES
1. Upload HUSBA-Claude-Final.zip unchanged to your GitHub repository ROOT and
   commit the upload. Do not delete files. Do not apply the original Claude ZIP.
2. Paste this into Codespaces:

(
set -e
cd /workspaces/husba
git switch main
git pull --ff-only
python3 - <<'CODE'
import zipfile
with zipfile.ZipFile("HUSBA-Claude-Final.zip") as z:
    exec(compile(z.read("apply-update.py"), "apply-update.py", "exec"))
CODE
git push origin main
)

The installer checks for existing tracked edits and patch conflicts before writing.
It runs build/check/tests before committing. A failure stops the process; send the
error instead of force-applying or deleting files.

The connected Cloudflare Pages project `husba` should deploy after the push.
Wait for a successful Pages production deployment, then refresh https://husba.pages.dev/.
Uploading the ZIP alone does not install the source update.
This package has not been deployed by the assistant.

VALIDATION
- Current baseline matched GitHub commit 32e5a32aea982c2598babfdabdd81c51354c5cd0.
- npm run build: passed.
- npm run check: passed (21 JS files, 48 frontend files).
- npm test: 13 passed, including 5 new API/escaping/filter/enquiry regression tests.
- Patch applied to an independent baseline copy; all resulting files matched.
- Browser screenshot/layout QA could not be completed in this environment because
  the browser runtime was unavailable; the earlier download attempt timed out.
- Tests use controlled API responses. No live customer enquiry or login was made.

QUICK PHONE CHECK
Home > menu > collection > filter/search > product > thumbnails > enquiry.
Confirm one clearly marked test enquiry arrives in admin. Check WhatsApp has the
correct product name/link. Try film play/pause, back navigation and reduced motion.
Check a 360px phone and a desktop viewport for wrapping and alignment.

PACKAGE CONTENTS
claude-design.patch — guarded update for the current project.
changed-files/ — complete changed source files, for inspection.
changed-files.json — exact path list.
apply-update.py — installer with build/check/test and local commit.

ROLLBACK
Use git revert <the-design-commit-hash> and git push origin main.
Do not reset secrets or delete the existing admin to roll back a public design.
