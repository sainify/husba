HUSBA fast startup and premium menu update
Apply premium-update.patch from the repository root with git apply. Run npm run build and npm run check, then commit and push the five changed frontend files. No Worker changes or secret changes required. Includes static shell cache v14. First visit installs the new cache; later openings use the cached shell. API requests still require network.
Validation: build, JavaScript checks, cache behavior tests passed. Mobile visual verification and live timing measurement still needed.
