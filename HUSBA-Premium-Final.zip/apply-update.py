import zipfile, json, hashlib, subprocess
from pathlib import Path

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest() if path.exists() else None

def run(*args):
    subprocess.run(args, check=True)

if subprocess.check_output(["git", "status", "--porcelain", "--untracked-files=no"]).strip():
    raise SystemExit("Please commit or save existing changes first. Nothing changed.")
with zipfile.ZipFile("HUSBA-Premium-Final.zip") as archive:
    manifest = json.loads(archive.read("update-manifest.json"))
    changed = []
    for name, info in manifest.items():
        current = digest(Path(name))
        if current not in info["allowed"]:
            raise SystemExit("Source differs from supported version: " + name + ". No files changed. Send latest source for merging.")
        data = archive.read("source/" + name)
        if hashlib.sha256(data).hexdigest() != info["sha256"]:
            raise SystemExit("ZIP validation failed. No files changed.")
        if current != info["sha256"]:
            changed.append(name)
    if changed:
        for name in changed:
            path = Path(name)
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(archive.read("source/" + name))
        for task in ("build", "check", "test"):
            run("npm", "run", task)
        run("git", "add", "--", *changed)
        run("git", "commit", "-m", "Refine HUSBA premium storefront and mobile navigation")
        print("Update committed. Push main to deploy through Cloudflare Pages.")
    else:
        print("This version is already applied.")
